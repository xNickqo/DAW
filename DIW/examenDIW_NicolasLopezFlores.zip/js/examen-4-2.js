$(window).on("load", inicio);

function inicio(){
    $("#tabs").tabs({
        collapsible: true
    });
}