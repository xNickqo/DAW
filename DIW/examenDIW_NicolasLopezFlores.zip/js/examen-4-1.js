$(window).on("load", inicio);

function inicio() {
    $("#desplegable").accordion({
        collapsible: true,
        active: false,
    });
}