$(window).on("load", inicio);

function inicio() {
    $("#menu").selectmenu();
    $("#menu").on("selectmenuchange", function() {
        var opcion = $(this).val();
        if (opcion) {
            window.location.href = opcion;
        }
    });
}