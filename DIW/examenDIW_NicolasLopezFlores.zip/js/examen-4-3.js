$(window).on("load", inicio);

function inicio(){
    $( "#fecha" ).datepicker();
    $( "input" ).tooltip();
}